<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="hostel";
$dbport="3307";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db, $dbport);
?>